# TODO:

*1.* counting minutes and how long to does it take to do stuff
*2.* make so you can choose example: mph to kmh instead of ONLY kmh to x